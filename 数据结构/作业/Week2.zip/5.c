#include <stdio.h>
#include <stdlib.h>
#define MaxSize 100
typedef int Elem;
typedef struct
{
    Elem *data;
    int length;
    int listsize;
} Sqlist, *PSqlist;
Sqlist InitList()
{
    Sqlist L;
    L.data = (Elem *)malloc(sizeof(Elem) * MaxSize);
    if (!L.data)
    {
        printf("Failed");
        exit(0);
    }
    L.length = 0;
    L.listsize = MaxSize;
    return L;
}
void PrintList(Sqlist L)
{
    int i;
	for (i = 0; i < L.length; i++)
        printf("%d ", L.data[i]);
}
void ListDelete(PSqlist L, int i)
{
    Elem k;
    for (k = i; k <= L->length; k++)
        L->data[k] = L->data[k + 1];
    L->length--;
}
void Sort(PSqlist p)
{
    int i,j;
	for (i = 0; i < p->length - 1; i++)
    {
        int min = i;                        //Ԥ���һ�������?��С
        for (j = i; j < p->length; j++) //��������ֿ�ʼ��������?
            if (p->data[min] > p->data[j])  //�ҵ�������֮����С���ֵ��±�
                min = j;
        if (min != i) //��������ʼ�����ֲ��������С����?
        {
            int temp = p->data[min]; //�����߽���λ��
            p->data[min] = p->data[i];
            p->data[i] = temp;
        }
    }
}
void Process(PSqlist a,PSqlist b)
{
    int i=1;
    for (i = 0; i < a->length && i < b->length && a->data[i] == b->data[i]; i++);
    if (i == a->length && i == b->length)
        printf("A=B");
    else if (i == a->length && i < b->length)
        printf("A<B");
    else if (i < a->length && i < b->length && a->data[i] < b->data[i])
        printf("A<B");
    else
        printf("A>B");
}
int main(void)
{
    int i;
	Sqlist a=InitList(), b=InitList();
    PSqlist p = &a, q = &b;
    scanf("%d", &a.length);
    for (i = 0; i < a.length; i++)
        scanf("%d", &a.data[i]);
    Sort(p);
    scanf("%d", &b.length);
    for (i = 0; i < b.length; i++)
        scanf("%d", &b.data[i]);
    Sort(q);
    Process(p, q);
	printf("\n");
    return 0;
}
