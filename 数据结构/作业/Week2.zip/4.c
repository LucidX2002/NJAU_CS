#include <stdio.h>
#include <stdlib.h>
#define MaxSize 100
typedef int Elem;
typedef struct
{
    Elem *data;
    int length;
    int listsize;
} Sqlist, *PSqlist;
Sqlist InitList()
{
    Sqlist L;
    L.data = (Elem *)malloc(sizeof(Elem) * MaxSize);
    if (!L.data)
    {
        printf("Failed");
        exit(0);
    }
    L.length = 0;
    L.listsize = MaxSize;
    return L;
}
void PrintList(Sqlist L)
{
    int i;
	for (i = 0; i < L.length; i++)
        printf("%d\t", L.data[i]);
}
void process(PSqlist p, PSqlist q, PSqlist r)
{
    int t=0,i,j;
    for (i = 0; i < p->length;i++)
    {
        for (j = 0; j < q->length;j++)
            if(p->data[i]==q->data[j]){
                if(r->data[t-1]==p->data[i])
                    continue;
                r->data[t++] = p->data[i];
                r->length = t;
            }
    }
}
int main(void)
{
    int i;
	Sqlist a = InitList(), b = InitList(), c = InitList();
    PSqlist p = &a, q = &b, r = &c;
    scanf("%d", &a.length);
    for (i = 0; i < a.length; i++)
        scanf("%d", &a.data[i]);
    scanf("%d", &b.length);
    for (i = 0; i < b.length; i++)
        scanf("%d", &b.data[i]);
    process(p, q, r);
    PrintList(c);
	printf("\n");
    return 0;
}