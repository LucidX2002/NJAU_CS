#include<stdio.h>
#include<stdlib.h>
#define MaxSize 100
typedef int Elem;
typedef struct{
    Elem *data;
    int length;
    int listsize;
} Sqlist,*PSqlist;
Sqlist InitList()
{
    Sqlist L;
    L.data = (Elem *)malloc(sizeof(Elem)*MaxSize);
    if(!L.data)
    {
        printf("Failed");
        exit(0);
    }
    L.length = 0;
    L.listsize = MaxSize;
    return L;
} 
void PrintList(Sqlist L)
{
    int i;
	for (i = 0; i < L.length;i++)
        printf("%d\t",L.data[i]);
}
void ListDelete(PSqlist L, int i,int *t) 
{
    Elem k;
    *t = L->data[i - 1];
    for (k = i-1; k <= L->length;k++)
        L->data[k] = L->data[k + 1];
    L->length--;
}
void Locate(Sqlist L, Elem e) 
{
    int i = 0;
    while(L.data[i]!=e)
        i++;
    if((i+1)<=L.length)
        printf("\n%d", i+1);
    else
        printf("\nNot found.");
}
int main(void)
{
	Sqlist L = InitList();
    PSqlist p = &L;
    int i,*t=&i;
    scanf("%d",&L.length);
    for (i = 0; i < L.length;i++)
        scanf("%d",&L.data[i]);
    scanf("%d", &i);
    ListDelete(p, i,t);
    scanf("%d", &i);
    printf("\n");
    PrintList(L);
    printf("\n%d", *t);
    Locate(L, i);
	printf("\n");
    return 0;
}
