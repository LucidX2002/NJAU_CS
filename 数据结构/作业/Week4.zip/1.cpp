#include<stdio.h>
#include<stdlib.h>
#define INIT_SIZE 100
#define INCREMENT 10
#define ElemType int
typedef struct{
    ElemType *top;
    ElemType *base;
    int StackSize;
} SqStack;
bool InitStack(SqStack &s);
bool ClearStack(SqStack &s);
bool StackEmpty(SqStack s);
bool DestroyStack(SqStack &s);
bool Push(SqStack &s, ElemType e);
bool Pop(SqStack &s, ElemType &e);
bool GetTop(SqStack s, ElemType &e);
bool PrintStack(SqStack s);
int main(void)
{
    int n,e;
	SqStack s;
    InitStack(s);
    scanf("%d",&n);
	while(n--)
	{
		scanf("%d",&e);
		Push(s,e);
	}
    scanf("%d", &n);
    while(n--){
        Pop(s,e);
    }
    if(!StackEmpty(s))
    {
        GetTop(s, e);
        printf("%d\n",e);
        PrintStack(s);
    }
    return 0;
}
bool InitStack(SqStack &s)
{
    s.base = (ElemType *)malloc(INIT_SIZE * sizeof(ElemType));
    if(!s.base)
        return false;
    s.top = s.base;
    s.StackSize = INIT_SIZE;
    return true;
}
bool ClearStack(SqStack &s)
{
    if(!s.base)
        return false;
    s.top = s.base;
		return true;
}
bool StackEmpty(SqStack s)
{
    if(!s.base)
    {
        printf("N\n");
        return false;
    }
    if(s.top==s.base)
    {
        printf("Y\n");
        return true;
    }
    else
    {
        printf("N\n");
        return false;
    }
}
bool DestroyStack(SqStack &s)
{
    if(!s.base)
        return false;
    free(s.base);
    s.base = s.top = NULL;
    s.StackSize = 0;
    return true;
}
bool Push(SqStack &s,ElemType e)
{
    
    if(s.top-s.base>=s.StackSize)
    {
        ElemType *newbase;
        newbase=(ElemType *)realloc(s.base,(s.StackSize+INCREMENT)*sizeof(ElemType));
        s.base = newbase;
        s.top = s.base + s.StackSize;
        s.StackSize += INCREMENT;
    }
    *s.top++ = e;
    return true;
}
bool Pop(SqStack &s,ElemType &e)
{
    if(s.top==s.base)
        return false;
    e = *--s.top;
    return true;
}
bool GetTop(SqStack s,ElemType &e)
{
    if(s.top==s.base)
        return false;
    e = *(s.top - 1);
    return true;
}
bool PrintStack(SqStack s)
{
    ElemType *p;
    if(s.top==s.base)
        return false;
    for (p = s.base; p < s.top;p++)
        printf("%d\t", *p);
    return true;
}
