#include<stdio.h>
#include<stdlib.h>
#define ElemType int
typedef struct LinkNode{
    ElemType data;
    struct LinkNode *next;
} * LinkStack, LinkNode;
void InitStack(LinkStack &S);
bool Push(LinkStack &S,ElemType e);
bool GetTop(LinkStack &S, ElemType &e);
bool Pop(LinkStack &S, ElemType &e);
bool PrintStack(LinkStack S);
bool StackEmpty(LinkStack S);
int main(void)
{
    LinkStack S;
    ElemType e;
    int n;
    InitStack(S);
    scanf("%d", &n);
    while(n--)
    {
        scanf("%d", &e);
        Push(S, e);
    }
    scanf("%d", &n);
    while(n--)
    {
        Pop(S, e);
    }
    if(!StackEmpty(S))
    {
        GetTop(S, e);
        printf("%d\n", e);
        PrintStack(S);
    }
    return 0;
}
void InitStack(LinkStack &S)
{
    S = NULL;
}
bool Push(LinkStack &S,ElemType e)
{
    LinkNode *p;
    p = (LinkNode *)malloc(sizeof(LinkNode));
    if(!p)
        return false;
    p->data = e;
    p->next = S;
    S = p;
    return true;
}
bool GetTop(LinkStack &S,ElemType &e)
{
    if(!S)
        return false;
    e = S->data;
    return true;
}
bool Pop(LinkStack &S,ElemType &e)
{
    LinkNode *p;
    if(!S)
        return false;
    e = S->data;
    p = S;
    S = S->next;
    free(p);
    return true;
}
bool StackEmpty(LinkStack S)
{
    if(!S)
    {
        printf("Y\n");
        return true;
    }  
    else
    {
        printf("N\n");
        return false;
    }    
}
bool StackDestroy(LinkStack &S)
{
    if(!S)
        return false;
    S = NULL;
    return false;
}
bool PrintStack(LinkStack S)
{
    LinkNode *p;
    if(!S)
        return false;
    p = S;
    while(p)
    {
        printf("%d\t", p->data);
        p = p->next;
    }
    return true;
}