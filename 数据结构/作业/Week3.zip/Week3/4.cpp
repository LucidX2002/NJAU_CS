#include<stdio.h>
#include<stdlib.h>
typedef struct DNode
{
    int code; //�������ͱ��� code ����������
    int key;  //�������ͱ��� key �����������
    struct DNode *next;
} DNode, *DLinkList;
bool InitList(DLinkList &L);
bool CreatList(DLinkList &L, int m);
void Jos(DLinkList &L, int m, int n);
int main(void)
{
    int n,m;
    DLinkList L;
    scanf("%d", &m);
    scanf("%d", &n);
    InitList(L);
    CreatList(L, n);
    Jos(L, n, m);
    return 0;
}
bool InitList(DLinkList &L)
{
    L = (DLinkList)malloc(sizeof(DNode));
    if(!L)
        return false;
    L->next = NULL;
    return true;
}
bool CreatList(DLinkList &L,int m)
{
    int i, tmp;
    DNode *p, *q;
    p = L;
    for (i = 1; i <= m;i++)
    {
        scanf("%d", &tmp);
        q = (DNode *)malloc(sizeof(DNode));
        if(!q)
            return false;
        q->code = i;
        q->key = tmp;
        p->next = q;
        p = q;
    }
    p->next = L->next;
	L = p;
    return true;
}
void Jos(DLinkList &L,int n,int m)
{
    DNode *p = L->next,*r=L;
    int i = 0,j = 1;
    while(i!=n)
    {
		if(j%m==0)
        {
			i++;
			printf("%d\t",p->code);
			r->next=p->next;
            m = p->key;
			free(p);
			p=r->next;
            j = 0;
        }
		else
		{
			r=p;
			p=p->next;
		}
        j++;
    }
}

