#include<stdio.h>
#include<stdlib.h>
typedef int ElemType;
typedef struct LNode
{
    ElemType data;
    struct LNode *next;
} LNode, *LinkList;
bool InitList(LinkList &L);
bool CreatList(LinkList &L, int n);
bool PrintList(LinkList L);
bool ListInsert(LinkList &L,int i,ElemType e);
bool ListDelete(LinkList &L, int i, ElemType &e);
int ListLength(LinkList L);
int main(void)
{
    int n = -1;
    int i = -1;
    LinkList L;
    InitList(L);
    CreatList(L,n);
    scanf("%d", &i);
    scanf("%d", &n);
    if(!ListInsert(L, i, n))
        printf("Insertion Location Error\n");
    scanf("%d", &i);
    if(!ListDelete(L,i,n))
        printf("Deletion Location Error\n");
    else
        printf("%d\n", n);
    printf("%d\n", ListLength(L));
    PrintList(L);
    return 0;
}
bool InitList(LinkList &L)
{
    L = (LinkList)malloc(sizeof(LNode));
    if (!L)
        return false;
    L->next = NULL;
    return true;
}
bool CreatList(LinkList &L,int n)
{
    int i;
    ElemType tmp;
    LNode *p, *q;
    p = L;
    scanf("%d", &n);
    for (i = 0; i < n;i++)
    {
        scanf("%d", &tmp);
        q = (LNode *)malloc(sizeof(LNode));
        if(!q)
            return false;
        q->data = tmp;
        p->next = q;
        p = q;
    }
    p->next = NULL;
    return true;
}
bool PrintList(LinkList L)
{
    LNode *p;
    if (!L)
        return false;
    p = L->next;
    while (p)
    {
        printf("%d\t", p->data);
        p = p->next;
    }
    printf("\n");
    return true;
}
bool ListInsert(LinkList &L,int i,ElemType e)
{
    LNode *p=L, *q;//�൱��pָ���0��λ��
    int j = 0;
    if(!L)
        return false;
    while(j<i-1)//ָ������λ�Ƶ���i-1��λ��
    {
        j++;
        p = p->next;
    }
    if(j>i||!p)
        return false;
    q = (LNode *)malloc(sizeof(LNode));//q�����ڵ�λ�þ��ǵ�i��λ��
    q->data = e;
    q->next = p->next;
    p->next = q;
    return true;
}
bool ListDelete(LinkList &L,int i,ElemType &e)
{
    LNode *pre = L, *p;
    int j = 0;
    if(!L)
        return false;
    while(j<i-1)
    {
        j++;
        pre = pre->next;
    }
    if(!pre||j>i)
        return false;
    p = pre->next;
    e = p->data;
    pre->next = p->next;
    free(p);
    return true;
}
int ListLength(LinkList L)
{
    LNode *p = L->next;
    int j = 0;
    while(p)
    {
        j++;
        p = p->next;
    }
    return j;
}
