#include<stdio.h>
#include<stdlib.h>
typedef struct LNode
{
    int coef;
    int expn;
    struct LNode *next;
} LNode, *LinkList;
bool InitList(LinkList &L);
bool CreatList(LinkList &L, int n);
bool MergeList(LinkList &La, LinkList &Lb);
bool PrintList(LinkList L);
int main(void)
{
    LinkList La, Lb;
    int m, n;
    InitList(La);
    InitList(Lb);
    scanf("%d", &m);
    CreatList(La, m);
    scanf("%d", &n);
    CreatList(Lb, n);
    MergeList(La, Lb);
    PrintList(La);
    return 0;
}
bool InitList(LinkList &L)
{
    L = (LinkList)malloc(sizeof(LNode));
    if(!L)
        return false;
    L->next=NULL;
    return true;
}
bool CreatList(LinkList &L,int n)
{
    int i = 0, c, e;
    LNode *p=L, *q;
    if(!L)
        return false;
    for (i = 0; i < n;i++)
    {
        scanf("%d", &c);
        scanf("%d", &e);
        q = (LNode *)malloc(sizeof(LNode));
        if(!q)
            return false;
        q->coef = c;
        q->expn = e;
        p->next = q;
        p = q;
    }
    p->next = NULL;
    return true;
}
bool MergeList(LinkList &La, LinkList &Lb)
{
    LNode *pa = La->next, *pb = Lb->next,*r=La;
    La->next = NULL;
    if(!La||!Lb)
        return false;
    while(pa&&pb)
    {
        if(pa->expn>pb->expn)
        {
            r->next = pa;
            r = pa;
            pa = pa->next;
        }
        else if(pa->expn<pb->expn)
        {
            r->next = pb;
            r = pb;
            pb = pb->next;
        }
        else
        {
            pa->coef += pb->coef;
            r->next = pa;
            r = pa;
            pa = pa->next;
            pb = pb->next;
        }
    }
    if(pa)
        r->next = pa;
    if(pb)
        r->next = pb;
    return true;
}
bool PrintList(LinkList L)
{
    LNode *p;
    if (!L)
        return false;
    p = L->next;
    while (p)
    {
        printf("%d\t%d\t", p->coef,p->expn);
        p = p->next;
    }
    printf("\n");
    return true;
}
