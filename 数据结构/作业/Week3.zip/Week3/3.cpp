#include <stdio.h>
#include <stdlib.h>
typedef int ElemType;
typedef struct LNode
{
    ElemType data;
    struct LNode *next;
} LNode, *LinkList;
bool InitList(LinkList &L);
bool CreatList(LinkList &L);
bool PrintList(LinkList L);
bool Cross(LinkList La, LinkList Lb, LinkList Lc);
int main(void)
{
    LinkList La,Lb,Lc;
    InitList(La);
    InitList(Lb);
    InitList(Lc);
    CreatList(La);
    CreatList(Lb);
    Cross(La, Lb, Lc);
    PrintList(Lc);
    return 0;
}
bool InitList(LinkList &L)
{
    L = (LinkList)malloc(sizeof(LNode));
    if(!L)
        return false;
    L->next = NULL;
    return true;
}
bool CreatList(LinkList &L)
{
    LNode *p, *q;
    int i;
    q = L;
    scanf("%d", &i);
    while (i != -1)
    {
        p = (LNode *)malloc(sizeof(LNode));
        if (!p)
            return false;
        p->data = i;
        q->next = p;
        q = p;
        scanf("%d", &i);
    }
    q->next = NULL;
    return true;
}
bool Cross(LinkList La, LinkList Lb, LinkList Lc)
{
    LNode *pa, *pb, *pc;
    if(!La||!Lb)
        return false;
    pa = La->next;
    pb = Lb->next;
    pc = Lc;
    while(pa&&pb)
    {
        if(pa->data==pb->data&&pc->data!=pa->data)
        {
            pc->next = pa;
            pc = pa;
            pa = pa->next;
            pb = pb->next;
        }
        else if(pa->data<pb->data)
            pa = pa->next;
        else
            pb = pb->next;
    }
    pc->next=NULL;
    return true;
}
bool PrintList(LinkList L)
{
    LNode *p;
    if (!L)
        return false;
    p = L->next;
    while (p)
    {
        printf("%d\t", p->data);
        p = p->next;
    }
    return true;
}
