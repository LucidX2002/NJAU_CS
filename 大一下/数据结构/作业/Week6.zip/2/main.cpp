#include"LinkQueue.h"
#include"BiTree.h"

int main()
{
	BiTree T;
	CreateBiTree(T);
	LevelOrderTraverse(T);
	printf("\n");
	return 0;
}