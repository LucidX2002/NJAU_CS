#include"Bitree.h"
int main()
{
	BiTree T1;
	CreateBiTree(T1);
	PreOrder(T1);
	printf(" ");
	InOrder(T1);
	printf(" ");
	PostOrder(T1);
	printf("\n%d %d\n",leaf(T1),Depth(T1));
	Exchangechild(T1);
	PreOrder(T1);
	printf(" ");
	InOrder(T1);
	printf(" ");
	PostOrder(T1);
	printf("\n");
	return 0;
}