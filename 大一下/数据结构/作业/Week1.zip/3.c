#include<stdio.h>
void swap(int *x, int *y);
int main(void)
{
    int a, b, *x, *y;
    x = &a;
    y = &b;
    scanf("%d%d", x, y);
    swap(x, y);
    printf("a=%d,b=%d", *x, *y);
    return 0;
}
void swap(int *x,int *y)
{
    int temp;
    temp = *x;
    *x = *y;
    *y = temp;
}