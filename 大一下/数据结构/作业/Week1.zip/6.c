#include<stdio.h>
#include<stdlib.h>
#include<time.h>
double ave(int a[], int n);
int over(int a[], double n);
int main(void)
{
    srand((unsigned)time(NULL));
    int a[50];
    for (int i = 0; i < 50;i++)
        a[i] = rand() % 20 + 80;
    printf("Ave=%.2lf", ave(a, 50));
    printf("\nOver average:%d", over(a, ave(a, 50)));
    return 0;
}
double ave(int a[],int n)
{
    double sum = 0;
    int *p;
    p = a;
    int i = n;
    while(i--)
    {
        sum += *p;
        p++;
    }
    return sum/n;
}
int over(int a[], double n)
{
    int i = 0,k=50;
    int *p;
    p = a;
    while(k--)
    {
        if(*p>n)
            i++;
        p++;
    }
    return i;
}
