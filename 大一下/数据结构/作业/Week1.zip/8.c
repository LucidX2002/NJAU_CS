#include<stdio.h>
#include<stdlib.h>
typedef struct DNode{
    int num;
    int state;
    struct DNode *next;
} DNode, *Dlinklist;
Dlinklist creat(int n);
void Jos(Dlinklist L, int n,int m);
int main(void)
{
    int n, m;
    scanf("%d%d", &n, &m);
    Jos(creat(n), n, m);
    return 0;
}
Dlinklist creat(int n)
{
    Dlinklist L;
    L = (Dlinklist)malloc(sizeof(DNode));
    DNode *s,*r=L;
    L -> next = NULL;
    for (int i = 0; i < n ;i++)
    {
        s = (DNode *)malloc(sizeof(DNode));
        s->num = i + 1;
        s->state = 1;
        r->next = s;
        r = s;
    }
    r->next = L->next;
    return L;
}
void Jos(Dlinklist L, int n,int m)
{
    DNode *p=L->next;
    int i = 1,j = 1;
    while(i!=n)
    {
        if(p->state){
            
            if(j%m==0)
            {
                p->state = 0;
                i++;
                printf("%d\t", p->num);
            }
            j++;
        }
        p = p->next;   
    }
    for (p = L->next; !(p->state);p=p->next);
    printf("\n%d", p->num);
}
