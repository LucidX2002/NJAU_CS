#include<stdio.h>
typedef struct 
{
    int num;
    char name[20];
    char gender[10];
    char adress[20];
} student;
int main(void)
{
    student stu1 = {
        24,
    "Alexis",
    "Male",
    "Nantong,Jiangsu",
    };
    printf("No.%d\tName:%s\tGender:%s\tAdress:%s\t", 
    stu1.num, stu1.name, stu1.gender, stu1.adress);
    return 0;
}
    