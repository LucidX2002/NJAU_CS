#include<stdio.h>
#include<stdlib.h>
#include<time.h>
typedef struct
{
    int no;
    char name[20];
    int score1, score2, score3;
    float ave;
} stu;
void putmax(stu a[],int n);
int main(void)
{
    srand((unsigned)time(NULL));
    stu list[5];
    int i;
    for (i = 0; i < 5;i++)
    {
        printf("\nNo.%d\t", i + 1);
        scanf("%d", &list[i].no);
        scanf("%s", list[i].name);
        printf("%d\t", list[i].score1 = rand() % 70 + 30);
        printf("%d\t", list[i].score2 = rand() % 70 + 30);
        printf("%d\t", list[i].score3 = rand() % 70 + 30);
        printf("%.2f\t", list[i].ave=(float)(list[i].score1 + list[i].score2 + list[i].score3) / 3);
    }
    putmax(list,5);
    return 0;
}
void putmax(stu a[],int n)
{
    int imax=0,i;
    stu *p;
    p = a;
    for (i = 0; i < n;i++)
    {
        if((p+imax)->ave<(p+i)->ave)
            imax = i;
    }
    printf("No.%d\nName:%s\nScore1:%d\nScore2:%d\nScore3:%d\n",
           a[imax].no, a[imax].name, a[imax].score1, a[imax].score2, a[imax].score3);
}