#include<stdio.h>
#include<time.h>
#include<stdlib.h>
int search(int a[], int n);
int main(void)
{
    srand((unsigned)time(NULL));
    int a[10], i;
    for (i = 0; i < 10;i++)
        printf("%d\t",a[i] = rand() % 10);
    printf("\nNo.%d is max.",search(a, 10)+1);
    return 0;
}
int search(int a[],int n)
{
    int *p,i=0,imax=0;
    p = a;
    while(i<10)
    {
        if(*(p+i)>*(p+imax))
            imax = i;
        i++;
    }
    return imax;
}