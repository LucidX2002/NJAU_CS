#include<stdio.h>
#include<stdlib.h>
typedef struct student{
    long int num;
    int score;
    struct student *next;
} stu, *stulist;
stulist Creat(stulist L);
stulist Insert(stulist L);
stulist Del(stulist L, long int key);
int Sum(stulist L);
void Searchmax(stulist L);
void Print(stulist L);
int main(void)
{
    stulist L;
    L = (stulist)malloc(sizeof(stu));
    long int key;
    L = Creat(L);
    L = Insert(L);
    printf("Please input the key:");
    scanf("%ld", &key);
    L = Del(L,key);
    printf("Sum=%d\n",Sum(L));
    Searchmax(L);
    Print(L);
    return 0;
}
stulist Creat(stulist L)
{
    L->next = NULL;
    return L;
}
stulist Insert(stulist L)
{
    stu *s,*r;
    long int x;

    L = (stulist)malloc(sizeof(stu));
    L->next = NULL;
    r = L;
    printf("Printf 9999 to stop.\n");
    scanf("%ld", &x);
    while (x != 9999)
    {
        s = (stulist)malloc(sizeof(stu));
        s->num = x;
        scanf("%d", &s->score);
        s->next = r->next;
        r->next = s;
        r = s;
        scanf("%ld", &x);
    }
    r->next = NULL;
    return L;
}
stulist Del(stulist L, long int key)
{
    stu *p= L->next,*q;
    while(p->num!= key && p)
        p = p->next;
    if(!(p->next)){
        free(p);
        return L;
    }
    q = p->next;
    p->score = q->score;
    p->num = q->num;
    p->next = q->next;
    free(q);
    return L;
}
int Sum(stulist L)
{
    int sum = 0;
    stu *p;
    p = L->next;
    while(p)
    {
        sum += p->score;
        p = p->next;
    }
    return sum;
}
void Searchmax(stulist L)
{
    stu *p,*q;
    p = L->next;
    q = L->next;
    while(p)
    {
        if(q->score<p->score)
            q = p;
        p=p->next;
    }
    printf("No.%ld Mark:%d is max.\n", q->num, q->score);
}
void Print(stulist L)
{
    stu *p=L->next;
    while(p)
    {
        printf("No.%ld,Mark %d\n", p->num, p->score);
        p=p->next;
    }
}
