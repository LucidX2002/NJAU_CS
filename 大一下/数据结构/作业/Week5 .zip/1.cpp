#include<stdio.h>
#include<stdlib.h>
#define ElemType int
typedef struct LinkNode{
    ElemType data;
    struct LinkNode *next;
} LinkNode;
typedef struct{
    LinkNode *front, *rear;
} LinkQueue;
void InitQueue(LinkQueue &Q);
bool IsEmpty(LinkQueue Q);
bool EnQueue(LinkQueue &Q, ElemType x);
bool DeQueue(LinkQueue &Q, ElemType &x);
bool GetFront(LinkQueue Q, ElemType &x);
bool PrintQueue(LinkQueue Q);
int main(void)
{
    LinkQueue Q;
    int n;
    ElemType x; 
    InitQueue(Q);
    scanf("%d", &n);
    while(n--)
    {
        scanf("%d", &x);
        EnQueue(Q, x);
    }
    scanf("%d", &n);
    while(n--)
    {
        DeQueue(Q, x);
    }
    if(IsEmpty(Q))
        printf("Y\n");
    else
        printf("N\n");
    if(GetFront(Q, x))
        printf("%d\n", x);
    PrintQueue(Q);
    return 0;
}
void InitQueue(LinkQueue &Q)
{
    Q.front = NULL;
    Q.rear = NULL;
}
bool IsEmpty(LinkQueue Q)
{
    if(Q.front==NULL)
        return true;
    else
        return false;
}
bool EnQueue(LinkQueue &Q,ElemType x)
{
    LinkNode *s = (LinkNode *)malloc(sizeof(LinkNode));
    if(!s)
        return false;
    s->data = x;
    s->next = NULL;
    if(Q.front==NULL)
    {
        Q.front = s;
        Q.rear = s;
    }
    else
    {
        Q.rear->next = s;
        Q.rear = s;
    } 
    return true;
}
bool DeQueue(LinkQueue &Q,ElemType &x)
{
    if(Q.front==NULL)
        return false;
    LinkNode *p = Q.front;
    x = p->data;
    Q.front = p->next;
    if(Q.rear==p)
    {
        Q.front = NULL;
        Q.rear = NULL;
    }
    free(p);
    return true;
}
bool GetFront(LinkQueue Q,ElemType &x)
{
    if(Q.front==NULL)
        return false;
    x = Q.front->data;
    return true;
}
bool PrintQueue(LinkQueue Q)
{
    if(Q.front==NULL)
        return false;
    LinkNode *p = Q.front;
    for (; p <= Q.rear&&p != NULL;p=p->next)
        printf("%d\t", p->data);
    return true;
}

