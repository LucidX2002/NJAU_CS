#include<stdio.h>
#include<stdlib.h>
#define N 2
#define PRICE 1 
typedef struct car
{
    int num;
    int time;
} Car;
typedef Car ElemType;
typedef struct Stack
{
    ElemType *base;
    ElemType *top;
    int Length;
}park, tmp;
park Park;
tmp Tmp;
typedef struct Node
{
    ElemType Car;
    struct Node *next;
} Node;
typedef struct Queue
{
    Node *rear;
    Node *front;
    int Length;
} line;
line Line;
bool InitStack(Stack &S);
bool InitQueue(Queue &Q);
void InCar(ElemType C);
bool InLine(ElemType C);
bool OutStack(Stack &S);
ElemType OutLine();
void DisPark();
void DisLine();
void Arrival(ElemType Car);
void Leave(ElemType Car);
bool Search(ElemType Car);
int main(void)
{
    char ch;
    Car c;
    InitStack(Park);
    InitStack(Tmp);
    InitQueue(Line);
    printf("A. The Car Arrive D. The Car Leave E. Exit System\n");
    while(1)
    {
        scanf("%c", &ch);
        switch (ch)
        {
            case 'A':
                scanf("%d",&c.num);
                scanf("%d",&c.time);
                Arrival(c);
                printf("A. The Car Arrive D. The Car Leave E. Exit System\n");
                break;
            case 'D':
                scanf("%d", &c.num);
                scanf("%d", &c.time);
                Leave(c);
                printf("A. The Car Arrive D. The Car Leave E. Exit System\n");
                break;
            case 'E':
                return 0;
            default:
                break;
        }
    }
    return 0;
}
bool InitStack(Stack &S)
{
    S.base = (ElemType *)malloc(sizeof(ElemType) * N);
    if(!S.base)
        return false;
    S.top = S.base;
    S.Length = 0;
    return true;
}
bool InitQueue(Queue &Q)
{
    Q.front = (Node *)malloc(sizeof(Node));
    if(!Q.front)
        return false;
    Q.front->next = NULL;
    Q.rear = Q.front;
    Q.Length = 0;
    return true;
}
void InCar(ElemType C)
{
    *Park.top = C;
    Park.top++;
    Park.Length++;
}
bool InLine(ElemType C)
{
    Node *s = (Node *)malloc(sizeof(Node));
    if(!s)
        return false;
    s->Car = C;
    s->next = NULL;
    Line.rear->next = s;
    Line.rear = s;
    Line.Length++;
    return true;
}
void InTmp(ElemType C)
{
    *(Tmp.top) = C;
    Tmp.top++;
    Tmp.Length++;
}
bool OutStack(Stack &S)
{
    if(S.Length==0)
        return false;
    S.top--;
    S.Length--;
    return true;
}
ElemType OutLine()
{
    Node *t = Line.front->next;
    ElemType a = t->Car;
    Line.front->next = t->next;
    Line.Length--;
    return a;
}
void DisPark()
{
    printf("Park:\n");
    ElemType *p =Park.base;
    while(p!=Park.top)
    {
        printf("No.%d %d\t", p->num, p->time);
        p++;
    }
}
void DisLine()
{
    printf("Line:\n");
    Node *p = Line.front->next;
    while(p)
    {
        printf("No.%d %d\t", (p->Car).num, (p->Car).time);
        p = p->next;
    }
}
void Arrival(ElemType Car)
{
    if(Park.Length<N)
    {
        InCar(Car);
        printf("Parking Location:%d\n", Park.Length);
    }
    else
    {
        InLine(Car);
        printf("Waiting Location:%d\n", Line.Length);
    }
}
bool Search(ElemType Car)
{
    ElemType *p = Park.base;
    while(p<=Park.top)
    {
        if(p->num==Car.num)
            return true;
        p++;
    }
    return false;
}
void Leave(ElemType c)
{
    if(Search(c))
    {
        Car *t = Park.top - 1;
        while (t->num != c.num && Park.top > Park.base)
        {
            InTmp(*t);
            OutStack(Park);
            t--;
        }
        int spendtime = c.time - t->time;
        printf("Time:%d Fee:%d\n", spendtime, spendtime * PRICE);
        Park.Length--;
        while(Tmp.Length>0)
        {
            OutStack(Tmp);
            InCar(*(Tmp.top));
        }
    }
    else
    {
        printf("Not exist.\n");
    }
}

