#include<stdio.h>
#include<stdlib.h>
#define MaxSize 10
#define ElemType int
typedef struct{
    ElemType data[MaxSize];
    int front, rear;
} SqQueue;
void InitQueue(SqQueue &Q);
bool IsEmpty(SqQueue Q);
bool EnQueue(SqQueue &Q, ElemType x);
bool DeQueue(SqQueue &Q, ElemType &x);
bool GetElem(SqQueue Q, ElemType &x);
bool PrintQueue(SqQueue Q);
int main(void)
{
    int i, n;
    SqQueue Q;
    InitQueue(Q);
    scanf("%d", &n);
    while(n--)
    {
        scanf("%d", &i);
        EnQueue(Q, i);
    }
    scanf("%d", &n);
    while(n--)
    {
        DeQueue(Q, i);
    }
    if(IsEmpty(Q))
        printf("Y\n");
    else
        printf("N\n");
    if(GetElem(Q, i))
        printf("%d\n", i);
    PrintQueue(Q);
    return 0;
}
void InitQueue(SqQueue &Q)
{
    Q.rear = 0;
    Q.front = 0;
}
bool IsEmpty(SqQueue Q)
{
    if(Q.rear==Q.front)
        return true;
    else
        return false;
}
bool EnQueue(SqQueue &Q,ElemType x)
{
    if((Q.rear+1)%MaxSize==Q.front)
        return false;
    Q.data[Q.rear] = x;
    Q.rear = (Q.rear + 1) % MaxSize;
    return true;
}
bool DeQueue(SqQueue &Q,ElemType &x)
{
    if(Q.rear==Q.front)
        return false;
    x = Q.data[Q.front];
    Q.front = (Q.front + 1) % MaxSize;
    return true;
}
bool GetElem(SqQueue Q,ElemType &x)
{
    if(Q.rear==Q.front)
        return false;
    x = Q.data[Q.front];
    return true;
}
bool PrintQueue(SqQueue Q)
{
    if(Q.rear==Q.front)
        return true;
    int i;
    for (i = Q.front; i < Q.rear;i=(i+1)%MaxSize)
        printf("%d\t", Q.data[i]);
    return true;
}