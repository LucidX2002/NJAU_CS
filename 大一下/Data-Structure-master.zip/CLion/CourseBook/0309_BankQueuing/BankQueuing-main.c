#include "BankQueuing.h"    //**▲03 栈和队列**//

int main(int argc, char** argv) {
    
    Bank_Simulation_1();            //算法3.6
    
//    Bank_Simulation_2();            //算法3.7，跟3.6类似

    return 0;
}
