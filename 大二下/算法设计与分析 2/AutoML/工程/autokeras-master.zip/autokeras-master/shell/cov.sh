pytest tests --cov-report html --cov-report xml:cov.xml --cov=autokeras
