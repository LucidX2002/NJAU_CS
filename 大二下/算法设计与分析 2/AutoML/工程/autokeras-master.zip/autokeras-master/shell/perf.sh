pytest tests/performance.py | tee perf_output.txt
