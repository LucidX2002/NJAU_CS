import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.StringTokenizer;
import javax.swing.*;
import javax.swing.border.*;
import com.intellij.uiDesigner.core.*;
/*
 * Created by JFormDesigner on Fri Jun 10 15:46:08 GMT+08:00 2022
 */



/**
 * @19220124 ���� 847232511@qq.com 18251377925 ����4#24
 */
public class CA19220124 extends JFrame {
    String str;
    FileDialog op = new FileDialog(this, "Open", FileDialog.LOAD);//�ļ��Ի���
    FileDialog sv = new FileDialog(this, "Save", FileDialog.SAVE);
    public CA19220124() {
        initComponents();
    }

    public static void main(String[] args) {
        CA19220124 demo = new CA19220124();
    }

    private void Open(ActionEvent e) {
        op.setVisible(true);//���ÿɼ�
        try {
            java.io.File f1 = new File(op.getDirectory(), op.getFile());//���ļ�
            FileReader fr = new FileReader(f1);
            BufferedReader br = new BufferedReader(fr);//��ȡ�ļ�
            textArea1.setText("");//�����ı�������Ϊ��
            while ((str = br.readLine()) != null){
                textArea1.append(str + '\n');
            }
            fr.close();//�رն�ȡ
        } catch (Exception e1) {//����д���������д���
            e1.printStackTrace();//��ӡ������Ϣ
        }
    }

    private void Count(ActionEvent e) {
        try{
            textArea2.setText("");
            str = textArea1.getText();
            if(str == null)  return;
            //hashset���治�ظ���ֵ ���
            HashSet<Character> hSet = new HashSet<Character>();
            char[] cs = str.toCharArray();
            for (char c : cs)
                hSet.add(c);
            ArrayList<Character> list = new ArrayList<Character>(hSet);
            int n = hSet.size();  //�ж������ַ�
            int[] times = new int[n];  //����ÿ���ַ��ĳ��ִ���
            for (char c : cs)   //����ͳ��
                times[list.indexOf(c)] ++;
            for (int i = 0; i < n; i++){
                textArea2.append("\n[" + list.get(i) + "] " + times[i] + "��\n");
            }
            textArea2.append("\n�ַ�����"+n+"��\n");
            //��ӡ���
        }catch (Exception e1) {//����д���������д���
            e1.printStackTrace();//��ӡ������Ϣ
        }
    }

    private void Save(ActionEvent e) {
        sv.setVisible(true);
        try {
            File f1 = new File(sv.getDirectory(), sv.getFile());
            FileWriter fw = new FileWriter(f1);
            BufferedWriter bw = new BufferedWriter(fw);
            String gt = textArea2.getText();//��ȡ�ı�������
            bw.write(gt, 0, gt.length());//���ı�������д���ļ�
            bw.flush();//������д���ļ�
            fw.close();//�ر�д��
        } catch (Exception e2) {//������
            e2.printStackTrace();//��ӡ������Ϣ
        }
    }

    private void Exit(ActionEvent e) {
        System.exit(0);//�رճ���
    }

    private void Search(ActionEvent e) {
        Search_Dialog.setVisible(true);
    }

    private void Search1(ActionEvent e) {
        textArea2.setText("");
        try{
            str = textArea1.getText();
            String str0 = str.replaceAll("\\pP|\\n"," ");
            StringTokenizer tok = new StringTokenizer(str0, " ");// ���ո� �����
            int n = tok.countTokens();
            int j,i=0;
            int[] data = new int[n];
            String[] strA = new String[n]; // �������麬n��Ԫ��
            while (tok.hasMoreTokens()) {
                strA[i] = tok.nextToken();
                data[i]=Integer.parseInt(strA[i]);
                i++;
            }
            int k =Integer.parseInt(textField2.getText().trim());
            int count = 1;
            int left = 0;// ��߽����
            int right = n - 1;// �ұ߽����
            int middle;// ��λ������
            while (left <= right) {
                middle = (left + right) / 2;
                if (k < data[middle]) {
                    right = middle - 1;// ����ǰ���
                } else if (k > data[middle]) {
                    left = middle + 1;// ���Һ���
                } else if (k == data[middle]) {
                    textArea2.append("�ҵ���"+data[middle]+"�ڵ�"+middle+"λ");
                    break;
                }
                textArea2.append("��"+count+"�飺"+"��"+data[left]+"��"+data[right]+"֮�䣬Ŀǰ�ҵ��˵�"+middle+"λ��"+data[middle]+"\n");
                count++;
            }
        }catch (Exception e2) {//������
            e2.printStackTrace();//��ӡ������Ϣ
        }
    }

    private void CLosr(ActionEvent e) {
        Search_Dialog.dispose();
    }


    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        dialogPane = new JPanel();
        contentPanel = new JPanel();
        panel1 = new JPanel();
        Open = new JButton();
        Search = new JButton();
        Count = new JButton();
        Save = new JButton();
        Exit = new JButton();
        panel3 = new JPanel();
        scrollPane1 = new JScrollPane();
        textArea1 = new JTextArea();
        scrollPane2 = new JScrollPane();
        textArea2 = new JTextArea();
        Search_Dialog = new JDialog();
        textField1 = new JTextField();
        textField2 = new JTextField();
        panel2 = new JPanel();
        button7 = new JButton();
        button6 = new JButton();

        //======== this ========
        setTitle("CA19220124");
        setMinimumSize(new Dimension(410, 285));
        setVisible(true);
        var contentPane = getContentPane();
        contentPane.setLayout(new BorderLayout());

        //======== dialogPane ========
        {
            dialogPane.setBorder(new EmptyBorder(12, 12, 12, 12));
            dialogPane.setLayout(new BorderLayout());

            //======== contentPanel ========
            {
                contentPanel.setLayout(new BorderLayout());

                //======== panel1 ========
                {
                    panel1.setLayout(new GridLayout(1, 5));

                    //---- Open ----
                    Open.setText("\u6253\u5f00\u6587\u4ef6");
                    Open.addActionListener(e -> Open(e));
                    panel1.add(Open);

                    //---- Search ----
                    Search.setText("\u6298\u534a\u67e5\u627e");
                    Search.addActionListener(e -> Search(e));
                    panel1.add(Search);

                    //---- Count ----
                    Count.setText("\u5b57\u9891\u7edf\u8ba1");
                    Count.addActionListener(e -> Count(e));
                    panel1.add(Count);

                    //---- Save ----
                    Save.setText("\u4fdd\u5b58\u6587\u4ef6");
                    Save.addActionListener(e -> Save(e));
                    panel1.add(Save);

                    //---- Exit ----
                    Exit.setText("\u9000\u51fa");
                    Exit.addActionListener(e -> Exit(e));
                    panel1.add(Exit);
                }
                contentPanel.add(panel1, BorderLayout.SOUTH);

                //======== panel3 ========
                {
                    panel3.setLayout(new GridLayout(2, 1));

                    //======== scrollPane1 ========
                    {

                        //---- textArea1 ----
                        textArea1.setLineWrap(true);
                        scrollPane1.setViewportView(textArea1);
                    }
                    panel3.add(scrollPane1);

                    //======== scrollPane2 ========
                    {

                        //---- textArea2 ----
                        textArea2.setLineWrap(true);
                        textArea2.setEditable(false);
                        scrollPane2.setViewportView(textArea2);
                    }
                    panel3.add(scrollPane2);
                }
                contentPanel.add(panel3, BorderLayout.CENTER);
            }
            dialogPane.add(contentPanel, BorderLayout.CENTER);
        }
        contentPane.add(dialogPane, BorderLayout.CENTER);
        pack();
        setLocationRelativeTo(getOwner());

        //======== Search_Dialog ========
        {
            Search_Dialog.setTitle("\u6298\u534a\u67e5\u627e");
            Search_Dialog.setMinimumSize(new Dimension(200, 100));
            var Search_DialogContentPane = Search_Dialog.getContentPane();
            Search_DialogContentPane.setLayout(new GridLayout(3, 1));

            //---- textField1 ----
            textField1.setText("\u8bf7\u8f93\u5165\u8981\u67e5\u627e\u7684\u6570\u5b57\uff1a");
            textField1.setEditable(false);
            Search_DialogContentPane.add(textField1);
            Search_DialogContentPane.add(textField2);

            //======== panel2 ========
            {
                panel2.setLayout(new GridLayout(1, 2));

                //---- button7 ----
                button7.setText("\u786e\u5b9a");
                button7.addActionListener(e -> Search1(e));
                panel2.add(button7);

                //---- button6 ----
                button6.setText("\u53d6\u6d88");
                button6.addActionListener(e -> CLosr(e));
                panel2.add(button6);
            }
            Search_DialogContentPane.add(panel2);
            Search_Dialog.pack();
            Search_Dialog.setLocationRelativeTo(Search_Dialog.getOwner());
        }
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    private JPanel dialogPane;
    private JPanel contentPanel;
    private JPanel panel1;
    private JButton Open;
    private JButton Search;
    private JButton Count;
    private JButton Save;
    private JButton Exit;
    private JPanel panel3;
    private JScrollPane scrollPane1;
    private JTextArea textArea1;
    private JScrollPane scrollPane2;
    private JTextArea textArea2;
    private JDialog Search_Dialog;
    private JTextField textField1;
    private JTextField textField2;
    private JPanel panel2;
    private JButton button7;
    private JButton button6;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
}
