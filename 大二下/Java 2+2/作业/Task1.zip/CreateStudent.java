package HomeWork.Task1;

class Student {
    String no;
    int age;
    String name;
    String note;
    void Display(){
        System.out.println("Student Information\t");
        System.out.println("No:" + no + '\t');
        System.out.println("Age:" + age + '\t');
        System.out.println("Name:" + name + '\t');
        System.out.println("Note:" + note + '\t');
    }
}

public class CreateStudent {
    public static void main(String[] args)
    {
        Student one=new Student();
        one.no="19220124";
        one.age=20;
        one.name="Xia Ye";
        one.note="NULL";
        one.Display();
    }
}