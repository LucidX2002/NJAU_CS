package HomeWork.Task1;

import java.awt.Point;
import java.util.Scanner;

class Distance{
    private Point pA, pB;
    public Distance(int x0,int y0,int x1,int y1){
        pA = new java.awt.Point(x0, y0);
        pB = new java.awt.Point(x1, y1);
    }

    public void printDistance() {
        System.out.println("Distance between " + pA + " and " + pB + " is " + pA.distance(pB));// 调用awt.Point类的distance()方法求pA到pB的距离
    }
}


public class Distance_Calculate {
    public static void main(String[] arguments){
        Scanner input = new Scanner(System.in);
        int x0 = input.nextInt();
        int y0 = input.nextInt();
        int x1 = input.nextInt();
        int y1 = input.nextInt();
        input.close();
        Distance d = new Distance(x0, y0, x1, y1);
        d.printDistance();
    }
}
