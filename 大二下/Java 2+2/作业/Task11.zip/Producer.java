package Operation11;

class Producer implements Runnable {
    private Message msg;
//  构造器msg获得message信息
    public Producer(Message msg) {
        this.msg = msg;
    }

    @Override
    //重写run()实现多线程入口
    public void run() {
        for (int i = 0; i < 100; i++) {
            if(i % 2 == 0) {
                this.msg.setInfo("产品一","零食");
            }else {
                this.msg.setInfo("产品二","酒水");
            }

        }
    }

}
