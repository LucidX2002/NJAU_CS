package Operation11;


class Message{
    private String title;
    private String content;
    private boolean flag = true;//表示生产或消费的形式
    //flag = true表示允许生产，此时消费者等待。false时不允许生产，直到产品被消费

    public synchronized void setInfo(String content,String title) {
        if(this.flag ==  false) {//无法进行生产，应该等待被消费
            try {
                super.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("生产产品中");
        this.content = content;
        //增加延迟
        try {
            Thread.sleep(10);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        this.title = title;
        this.flag = false;//已完成生产
        super.notify();//唤醒等待的线程
    }
    public synchronized String getInfo() {
        if(this.flag ==  true) {//还未生产，需要等待
            try {
                super.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        //增加延迟
        try {
            Thread.sleep(10);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {
            return this.content + "---"+this.title;
        } finally {	//不管如何都要执行
            this.flag = true;//继续生产
            super.notify();//唤醒等待线程
        }

    }
}

