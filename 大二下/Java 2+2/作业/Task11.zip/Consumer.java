package Operation11;

class Consumer implements Runnable {
    private Message msg;
    public Consumer(Message msg) {
        this.msg = msg;
    }

    public void run() {
        for (int i = 0; i < 100; i++) {
            System.out.println("消费："+this.msg.getInfo());
        }
    }
}
