package Operation11;

public class ProducersAndConsumers {
    public static void main(String[] args) {
        Message msg = new Message();
        new Thread(new Producer(msg)).start();//启动生产者线程
        new Thread(new Consumer(msg)).start();//启动消费者线程
    }
}
