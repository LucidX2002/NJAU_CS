package iO;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Question2 extends JFrame {
	FileWriter wfile;
	BufferedWriter bufwriter;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Question2 frame = new Question2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Question2() {
		try {
			wfile=new FileWriter("D:\\eclipse-workspace\\JAVA\\src\\iO\\1.txt");
			bufwriter = new BufferedWriter(wfile);
		} catch (IOException e2) {
			// TODO �Զ����ɵ� catch ��
			e2.printStackTrace();
		}
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 538, 368);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u59D3\u540D\uFF1A");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 20));
		lblNewLabel.setBounds(76, 39, 110, 48);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(224, 38, 177, 41);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("\u5E74\u9F84\uFF1A");
		lblNewLabel_1.setFont(new Font("����", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(77, 115, 110, 48);
		contentPane.add(lblNewLabel_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(224, 115, 177, 41);
		contentPane.add(textField_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("\u7535\u8BDD\u53F7\u7801\uFF1A");
		lblNewLabel_1_1.setFont(new Font("����", Font.PLAIN, 20));
		lblNewLabel_1_1.setBounds(76, 183, 110, 48);
		contentPane.add(lblNewLabel_1_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(224, 183, 177, 41);
		contentPane.add(textField_2);
		
		JButton btnNewButton = new JButton("\u4E0B\u4E00\u4E2A");//����һ������ť ��ȡ��Ϣ���������ļ�
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String s="";
				String name;
				name = textField.getText();
				String age;
				age = textField_1.getText();
				String phone;
				phone = textField_2.getText();
				try {
					bufwriter.write(name+" "+age+" "+phone+" "+"\n");//��������ʦppt���Ҫ��
					bufwriter.flush();
				} catch (IOException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				//Person p=new Person(name,age,phone);//��ObjectOutputStream���ַ���txt�ļ����������
				//Fileput fp=new Fileput();
				//fp.WriteObj(p);
				textField.setText(s);
				textField_1.setText(s);
				textField_2.setText(s);
			}
		});
		btnNewButton.setFont(new Font("����", Font.PLAIN, 17));
		btnNewButton.setBounds(76, 254, 145, 48);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\u5B8C\u6210");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String s="";
				String name;
				name = textField.getText();
				String age;
				age = textField_1.getText();
				String phone;
				phone = textField_2.getText();
				try {
					bufwriter.write(name+" "+age+" "+phone+" ");
					bufwriter.flush();
				} catch (IOException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				//Person p=new Person(name,age,phone);
				//Fileput fp=new Fileput();
				//fp.WriteObj(p);
				System.exit(0);
			}
		});
		btnNewButton_1.setFont(new Font("����", Font.PLAIN, 17));
		btnNewButton_1.setBounds(242, 254, 145, 48);
		contentPane.add(btnNewButton_1);
	}
}
