//�ƿ�201 ���� 19220124
package iO;

import java.io.*;
import javax.swing.JOptionPane;

class DataOut {
	public static void main(String[] args) throws IOException {
		try {
			FileOutputStream fout = new FileOutputStream("D:\\eclipse\\data2022.dat");
			DataOutputStream out = new DataOutputStream(fout);
			String[] items = { "���", "��", "����", "����", "ë��" };
			int[] units = { 5, 2, 1, 2, 3 };
			float[] prices = { 1.5f, 2.8f, 125f, 7.2f, 5.6f };
			for (int i = 0; i < items.length; i++) {
				out.writeUTF(items[i]);
				out.writeChar('\t');
				out.writeFloat(prices[i]);
				out.writeChar('\t');
				out.writeInt(units[i]);

			}
			JOptionPane.showMessageDialog(null, "records are writed ");
			out.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		String s;
		FileInputStream infout = new FileInputStream(new File("D:\\eclipse\\data2022.dat"));
		BufferedReader bf= new BufferedReader(new InputStreamReader(infout,"UTF-8"));
		while((s=bf.readLine())!=null) {
			System.out.println(s);
		}
		bf.close();
	}
}