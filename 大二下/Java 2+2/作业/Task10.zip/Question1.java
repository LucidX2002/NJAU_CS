
package iO;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class Question1 {
	public static void main(String[] args) throws IOException {
		InputStream in = System.in;
		FileOutputStream out = null;
		try {
			out = new FileOutputStream("D:\\eclipse\\KeyTypein.txt");
			int c;
			while ((c = in.read()) != 13) {
				out.write(c);
			}
			System.out.println("������ϣ�");
		} finally {
			if (in != null) {
				in.close();
			}
			if (out != null) {
				out.close();
			}
		}
	}
}
