package HomeWork.Test4.Cardgame;

import java.util.ArrayList;

public class Card {
    private String num;
    private String color;
    
    public Card()
    {
    }

    public Card(String color,String num)
    {
        this.color = color;
        this.num = num;
    }
    
    public String getNum()
    {
        return num;
    }

    public String getColor()
    {
        return color;
    }
    
    public double getValue(){
        double val;
        String tmp=this.getNum();
        switch(tmp){
            case "A":
                val = 1;
                break;
            case "J":
            case "Q":
            case "K":
                val = 0.5;
                break;
            default:
                val = Integer.parseInt(tmp);
                break;
        }
        return val;
    }

    public void showCard()
    {
        System.out.println(this.getNum()+" "+this.getColor());
    }
    
    public static void main(String[] args){
        String[] numbers = { "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K" };
        String[] colors = { "红桃", "黑桃", "方片", "梅花" };
        ArrayList<Card> desk = new ArrayList<Card>();
        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 13; j++){
                Card Cardi = new Card(colors[i],numbers[j]);
                desk.add(Cardi);
            }
        for (int i=0;i<desk.size();i++)
            desk.get(i).showCard();
    }
}

