# Readme

## 1 程序介绍

* 程序分为card，init，player，boss，game，twoBoss六个类；

* 其中boss是player的子类，twoBoss是game的子类;
* game中是21点的主体程序部分,运行该文件的main函数,可以进行快乐游戏;
* twoBoss是额外设置的双机对战游戏.

## 2 特色介绍

* 机器采用**伪数学期望对当前牌面局势**进行分析,计算下一张牌的伪期望值,作为判断依据;

* 通过**理智权重(r)**,调节期望值在机器判断中的权重;

  ```java
  public String judge(Init Game,Player p){
          String ans = "N";
          if(r==0){
              ans = "Y";
              return ans;
          } //在理性权重为0时，跳过判断过程保持要牌
          expPoint = (double)this.getPoint() + r * Game.getExp();//设置理性权重
          if(expPoint<21.50)
              ans = "Y";
          else if(p.getPoint()>this.getPoint())
              ans = "Y";//在当前点数小于对方点数的情况下保持要牌
          return ans;
      }
  ```

* 通过**双机对战模式**,将两个机器**设置不同的理智权重(r)**,可通过大量游戏样本分析判断策略的优劣.

## 3 操作说明

### 3.1 game.java

* 在game中,先设置**游戏轮数(round)**,再设置机器**理智权重(r)**,开始游戏对局;

  ![image-20220408095501280](C:\Users\Lucid-X\AppData\Roaming\Typora\typora-user-images\image-20220408095501280.png)

* 开始游戏对局先默认抽取两张牌,并**询问是否继续抽牌**;

  ![image-20220408095552358](C:\Users\Lucid-X\AppData\Roaming\Typora\typora-user-images\image-20220408095552358.png)

* 继续进行游戏,结束后**显示当前回合游戏结果**;

  ![image-20220408095704837](C:\Users\Lucid-X\AppData\Roaming\Typora\typora-user-images\image-20220408095704837.png)

* 所有回合结束后,**显示计分板(scoreboard)**,显示胜率和平局率;

  ![image-20220408095906351](C:\Users\Lucid-X\AppData\Roaming\Typora\typora-user-images\image-20220408095906351.png)

### 3.2 twoBoss.java

* 在双boss中设置两个机器的理智权重和游戏回合数

  ![image-20220408100537462](C:\Users\Lucid-X\AppData\Roaming\Typora\typora-user-images\image-20220408100537462.png)

* 所有回合结束后,**显示计分板(scoreboard)**,显示胜率和平局率;

  ![image-20220408100722528](C:\Users\Lucid-X\AppData\Roaming\Typora\typora-user-images\image-20220408100722528.png)

## 4.改进方向

* 寻找更加合适的21点解决策略,尝试把伪期望改成真期望;
* 尝试做出GUI