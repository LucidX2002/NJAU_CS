package HomeWork.Test4.Cardgame;

import java.util.ArrayList;
import java.util.Scanner;

public class Boss extends Player{
    
    double expPoint;//预期点数
    double r;//理性值参数

    public Boss(){
        this.playerName = "Default";
        expPoint = 0;
        r = 1;
    }

    public Boss(String k){  
        this.playerName=k;
    }
    
    public void setR(double k){
        this.r=k;
    }

    public String judge(Init Game,Player p){
        String ans = "N";
        if(r==0){
            ans = "Y";
            return ans;
        } //在理性权重为0时，跳过判断过程保持要牌
        expPoint = (double)this.getPoint() + r * Game.getExp();//设置理性权重
        if(expPoint<21.50)
            ans = "Y";
        else if(p.getPoint()>this.getPoint())
            ans = "Y";//在当前点数小于对方点数的情况下保持要牌
        return ans;
    }

    public static void main(String args[]){
        Scanner in = new Scanner(System.in);
        ArrayList<String> table = new ArrayList<String>();
        for (int i = 1; i <= 5; i++) {
            System.out.println("BO" + i + ":");
            Init Game = new Init();
            Game.shuffle();
            Player p1 = new Player();
            Boss p2 = new Boss(); 
            String t = in.nextLine();
            while (t.equals("Y") || t.equals("y")) {
                System.out.println("Player1:");
                p1.getCard(Game.getCard());
                p1.showCard(p1.getHand().size() - 1);
                if(p1.boom()){
                    System.out.println("Player1 boom:"+ p1.getPoint());
                    break;
                }
                if (p2.judge(Game, p1).equals("Y")) {
                    System.out.println("Player2:");
                    p2.getCard(Game.getCard());
                    p2.showCard(p2.getHand().size() - 1);
                    if (p2.boom()) {
                        System.out.println("Player2 boom:" + p2.getPoint());
                        break;
                    }
                } else
                    System.out.println("Player2 Finished");
                t = in.nextLine();
            }
            while (p1.boom()==false  && p2.boom()==false) {
                System.out.println("Player1 Finished");
                if (p2.judge(Game, p1).equals("Y")) {
                    p2.getCard(Game.getCard());
                    p2.showCard(p2.getHand().size() - 1);
                    if (p2.boom()) {
                        System.out.println("Player2 boom:" + p2.getPoint());
                        break;
                    }
                } else {
                    System.out.println("Player2 Finished");
                    break;
                }
            }
            
            System.out.println("Player1 final point:" + p1.getPoint());
            System.out.println("Player2 final point:" + p2.getPoint());
            
            if(p1 == Game.whoWin(p1, p2)){
                System.out.println("Win");
                table.add("Win");
            }else if (p2 == Game.whoWin(p1, p2)){
                System.out.println("Lose");
                table.add("Lose");
            }else{
                System.out.println("Draw");
                table.add("Draw");
            }
        }   
        for(String i:table)
        {
            System.out.println(i);
        }
        in.close();
    }
    
}
