package HomeWork.Test4.Cardgame;

import java.util.ArrayList;
import java.util.Random;

public class Init {
    String[] colors = { "红桃", "黑桃", "方片", "梅花" };
    String[] numbers = { "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K" };
    double totalPoint;
    double exp;
    public ArrayList<Card> desk = new ArrayList<Card>();

    public Init(){
        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 13; j++) {
                Card Card = new Card(colors[i], numbers[j]);
                desk.add(Card);
            }
        totalPoint = 238;
        exp = 7;
    }

    public double getTotalpoint(){
        return this.totalPoint;
    }

    public double getExp(){
        return this.exp;
    }

    public ArrayList<Card> getDesk(){
        return this.desk;
    }

    public void showDesk(){
        for(Card i:desk){
            i.showCard();
        }
    }

    public void shuffle(){
        Random r = new Random();
        ArrayList<Card> temp = new ArrayList<Card>();
        for(int i = desk.size() ;i > 0;i--){
            int k = r.nextInt(i);
            temp.add(desk.get(k));
            desk.remove(k);
        }
        desk=temp;
        temp=null;
    }

    public Card getCard(){
        Card Card = desk.get(0);
        desk.remove(0);
        this.totalPoint -= Card.getValue();
        this.exp = this.totalPoint/this.getDesk().size();
        return Card;
    }

    public Player whoWin(Player p1,Player p2){
        if(p1.getPoint()>21)
            return p2;
        else if(p2.getPoint()>21)
            return p1;
        else if(p1.getPoint()>p2.getPoint())
            return p1;
        else if(p1.getPoint()<p2.getPoint())
            return p2;
        else 
            return null;
    }

    public static void main(String args[]){
        Init Game = new Init();
        Game.shuffle();
        Game.showDesk();
        System.out.println();
        Game.getCard().showCard();
        System.out.printf("%1.2f\n",Game.getExp());
        System.out.println(Game.getTotalpoint());
    }
}
