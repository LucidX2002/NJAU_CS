package HomeWork.Test4.Cardgame;

import java.util.ArrayList;
import java.util.Scanner;

public class Player {
    public String playerName;
    public double point;
    ArrayList<Card> hand = new ArrayList<Card>();

    public Player(){
        point = 0;
    }

    public void initial(){
        point=0;
        hand.removeAll(hand);
    }

    public Player(String i){
        this.playerName=i;
    }

    public ArrayList<Card> getHand(){
        return this.hand;
    }
    
    public String getPlayername(){
        return this.playerName;
    }
    public void showCard(){
        for(Card i:hand)
            i.showCard();
    }

    public void showCard(int i){
        hand.get(i).showCard();
    }

    public double getPoint(){
        return this.point;
    }

    public int getSize(){
        return this.hand.size();
    }
    public void getCard(Card i){  
        hand.add(i);
        point+=i.getValue();
    }

    public boolean boom(){
        if(this.getPoint()>21)
            return true;
        else 
            return false;
    }

    public boolean win(){
        if (this.getPoint()==21.00)
            return true;
        else 
            return false;
    }
    public static void main(String args[]) {
        Init Game = new Init();
        Game.shuffle();
        Game.showDesk();
        System.out.println();
        Player p1=new Player();
        Scanner in = new Scanner(System.in);
        String t = in.nextLine();
        while(t.equals("Y")||t.equals("y")){
            p1.getCard(Game.getCard());
            p1.showCard(p1.getHand().size()-1);
            t=in.nextLine();
        }
        p1.showCard();
        System.out.println(p1.getPoint());
        in.close();
    }
}
