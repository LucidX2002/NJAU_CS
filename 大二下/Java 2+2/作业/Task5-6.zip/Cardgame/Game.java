package HomeWork.Test4.Cardgame;

import java.util.ArrayList;
import java.util.Scanner;

public class Game {
    ArrayList <String> scoreBoard = new ArrayList <String>();
    private Player p1;
    private Boss p2;
    int win;
    int draw;
    int round;
    Scanner in = new Scanner(System.in);
    

    public Game(){
        p1 = new Player("Player1");
        p2 = new Boss("King");
        round = 0;
        win=0;
        draw=0;
    }
    
    public void setRound(int i){
        round = i;
    }

    public void showScore(){
        int k = 0;
        for(String i:scoreBoard){
            k++;
            System.out.println("Round"+k+":"+'\t'+i);
        }
        double winRate = (double) win/round;
        double drawRate = (double) draw / round;
        System.out.println("winRate:"  + 100 * winRate  + "%");
        System.out.println("drawRate:" + 100 * drawRate + "%");
    }

    public Boss getBoss(){
        return this.p2;
    }

    public int getRound(){
        return this.round;
    }

    public void coreGame(){
        Init Game = new Init();
        Game.shuffle();
        p1.initial();
        p2.initial();
        String t = "Y";
        int k=1;
        while (t.equals("Y") || t.equals("y")) {
            System.out.println(p1.getPlayername());
            p1.getCard(Game.getCard());
            p1.showCard(p1.getHand().size() - 1);
            if (p1.boom()) {
                System.out.println(p1.getPlayername()+" boom: "+ p1.getPoint());
                break;
            }else if(p1.win()){
                break;
            }
            if (p2.judge(Game, p1).equals("Y")) {
                System.out.println(p2.getPlayername());
                p2.getCard(Game.getCard());
                p2.showCard(p2.getHand().size() - 1);
                if (p2.boom()) {
                    System.out.println(p2.getPlayername() + " boom: " + p2.getPoint());
                    break;
                } else if (p1.win()) {
                    break;
                }
            }
            else
                System.out.println(p2.playerName+" Finished.");
            if(k!=0)
                k--;
            else{
                System.out.println("Current point: "+p1.getPoint()+" Keep?");
                t = in.nextLine();
            }
                
        }
        while (p1.boom() == false && p2.boom() == false && p1.win() == false && p2.win() == false) {
            System.out.println("Player1 Finished");
            if (p2.judge(Game, p1).equals("Y")) {
                p2.getCard(Game.getCard());
                p2.showCard(p2.getHand().size() - 1);
                if (p2.boom()) {
                    System.out.println(p2.getPlayername() + " boom: " + p2.getPoint());
                    break;
                }
            } else {
                System.out.println("Player2 Finished");
                break;
            }
        }
       
        System.out.println(p1.getPlayername() + " final point: " + p1.getPoint());
        System.out.println(p2.getPlayername() + " final point: " + p2.getPoint());
        
        if (p1 == Game.whoWin(p1, p2)) {
            System.out.println("Win");
            scoreBoard.add("Win");
            this.win++;
        } else if (p2 == Game.whoWin(p1, p2)) {
            System.out.println("Lose");
            scoreBoard.add("Lose");
        } else {
            System.out.println("Draw");
            scoreBoard.add("Draw");
            this.draw++;
        }
    }

    public static void main(String args[]){
        Game Game = new Game();
        Scanner in = new Scanner(System.in);
        System.out.println("Input rounds:");//输入游戏轮数
        int k =in.nextInt();
        System.out.println("Input rationality(0~1):");//输入机器理性程度
        double r =in.nextDouble();
        Game.getBoss().setR(r);
        Game.setRound(k);
        for(int i = 1;i <= Game.getRound() ;i++){
            System.out.println("Round"+i+":");
            Game.coreGame();
            System.out.println();
        } 
        System.out.println();
        Game.showScore();
        in.close();
    }
}
