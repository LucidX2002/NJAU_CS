package HomeWork.Test4.Cardgame;

import java.util.Scanner;

public class twoBoss extends Game{
    private Boss p1;
    private Boss p2;

    public twoBoss(String k1,String k2){
        p1=new Boss(k1);
        p2=new Boss(k2);
    }

    public void setR(double r1,double r2){
        p1.setR(r1);
        p2.setR(r2);
    }

    public void coreGame() {
        Init Game = new Init();
        Game.shuffle();
        p1.initial();
        p2.initial();
        String t = p1.judge(Game, p2);
        while (t.equals("Y") || t.equals("y")) {
            System.out.println(p1.getPlayername());
            p1.getCard(Game.getCard());
            p1.showCard(p1.getHand().size() - 1);
            if (p1.boom()) {
                System.out.println(p1.getPlayername() + " boom: " + p1.getPoint());
                break;
            } else if (p1.win()) {
                break;
            }
            if (p2.judge(Game, p1).equals("Y")) {
                System.out.println(p2.getPlayername());
                p2.getCard(Game.getCard());
                p2.showCard(p2.getHand().size() - 1);
                if (p2.boom()) {
                    System.out.println(p2.getPlayername() + " boom: " + p2.getPoint());
                    break;
                } else if (p1.win()) {
                    break;
                }
            } else
                System.out.println(p2.playerName + " Finished.");
            t = p1.judge(Game, p2);
        }
        while (p1.boom() == false && p2.boom() == false && p1.win() == false && p2.win() == false) {
            System.out.println("Player1 Finished");
            if (p2.judge(Game, p1).equals("Y")) {
                p2.getCard(Game.getCard());
                p2.showCard(p2.getHand().size() - 1);
                if (p2.boom()) {
                    System.out.println(p2.getPlayername() + " boom: " + p2.getPoint());
                    break;
                }
            } else {
                System.out.println("Player2 Finished");
                break;
            }
        }

        System.out.println(p1.getPlayername() + " final point: " + p1.getPoint());
        System.out.println(p2.getPlayername() + " final point: " + p2.getPoint());

        if (p1 == Game.whoWin(p1, p2)) {
            System.out.println("Win");
            scoreBoard.add("Win");
            this.win++;
        } else if (p2 == Game.whoWin(p1, p2)) {
            System.out.println("Lose");
            scoreBoard.add("Lose");
        } else {
            System.out.println("Draw");
            scoreBoard.add("Draw");
            this.draw++;
        }
    }
    
    public static void main(String args[]){
        twoBoss Game = new twoBoss("King", "Prince");
        Scanner in = new Scanner(System.in);
        System.out.println("Input rationality a,b:");
        double a = in.nextDouble();
        double b = in.nextDouble();
        Game.setR(a, b);//设置机器理性 程度
        System.out.println("Input round:");
        int k = in.nextInt();// 输入游戏轮数
        Game.setRound(k);
        for (int i = 1; i <= Game.getRound(); i++) {
            System.out.println("Round" + i + ":");
            Game.coreGame();
            System.out.println();
        }
        System.out.println();
        Game.showScore();
        in.close();
    }
}
