package HomeWork.Test3;

import java.util.Scanner;

public class GCD {
    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        System.out.println("Please enter 2 numbers:");
        int m = in.nextInt();
        int n = in.nextInt();
        int r=m%n;
        System.out.print(m+" and "+n+" 's"+" greatest common divisor is " );
        while(r!=0){
            m=n;
            n=r;
            r=m%n;
        }
        System.out.println(n);
        in.close();
    }
}
