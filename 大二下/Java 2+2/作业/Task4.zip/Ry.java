package HomeWork.Test3;

import java.util.Scanner;

public class Ry {
    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        System.out.println("Enter a year");
        int year = in.nextInt();
        if(year%4==0&&year%100!=0)
            System.out.println("Leap Year");
        else
            System.out.println("Not Leap Year");
        in.close();
    }
}
