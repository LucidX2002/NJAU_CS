package myFirstGUI;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JTextPane;

public class Test {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Test window = new Test();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Test() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 523, 312);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u6B22\u8FCE\u6765\u5230\u5357\u4EAC\u519C\u4E1A\u5927\u5B66666");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 35));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(0, 0, 443, 62);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnSayHello = new JButton("\u6253\u5F00\u6587\u4EF6");
		btnSayHello.setFont(new Font("����", Font.PLAIN, 20));
		btnSayHello.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnSayHello.setBounds(385, 53, 122, 46);
		frame.getContentPane().add(btnSayHello);
		
		JButton btnSayHello_1 = new JButton("\u6E05\u6D17");
		btnSayHello_1.setFont(new Font("����", Font.PLAIN, 20));
		btnSayHello_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnSayHello_1.setBounds(385, 109, 122, 46);
		frame.getContentPane().add(btnSayHello_1);
		
		JButton btnSayHello_2 = new JButton("\u4FDD\u5B58");
		btnSayHello_2.setFont(new Font("����", Font.PLAIN, 20));
		btnSayHello_2.setBounds(385, 221, 122, 46);
		frame.getContentPane().add(btnSayHello_2);
		
		JButton btnSayHello_3 = new JButton("\u9000\u51FA");
		btnSayHello_3.setFont(new Font("����", Font.PLAIN, 20));
		btnSayHello_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnSayHello_3.setBounds(385, 165, 122, 46);
		frame.getContentPane().add(btnSayHello_3);
		
		JTextPane textPane = new JTextPane();
		textPane.setFont(new Font("����", Font.PLAIN, 18));
		textPane.setText("\u5357\u4EAC\u519C\u4E1A\u5927\u5B66\u5750\u843D\u4E8E\u949F\u7075\u6BD3\u79C0\u3001\u864E\u8E1E\u9F99\u87E0\u7684\u53E4\u90FD\u5357\u4EAC\uFF0C\u662F\u4E00\u6240\u4EE5\u519C\u4E1A\u548C\u751F\u547D\u79D1\u5B66\u4E3A\u4F18\u52BF\u548C\u7279\u8272\uFF0C\u519C\u3001\u7406\u3001\u7ECF\u3001\u7BA1\u3001\u5DE5\u3001\u6587\u3001\u6CD5\u5B66\u591A\u5B66\u79D1\u534F\u8C03\u53D1\u5C55\u7684\u6559\u80B2\u90E8\u76F4\u5C5E\u5168\u56FD\u91CD\u70B9\u5927\u5B66\uFF0C\u662F\u56FD\u5BB6\u201C211\u5DE5\u7A0B\u201D\u91CD\u70B9\u5EFA\u8BBE\u5927\u5B66\u3001\u201C985\u4F18\u52BF\u5B66\u79D1\u521B\u65B0\u5E73\u53F0\u201D\u548C\u201C\u53CC\u4E00\u6D41\u201D\u5EFA\u8BBE\u9AD8\u6821\u3002\u73B0\u4EFB\u6821\u515A\u59D4\u4E66\u8BB0\u9648\u5229\u6839\u6559\u6388\uFF0C\u6821\u957F\u9648\u53D1\u68E3\u6559\u6388\u3002\r\n");
		textPane.setBounds(10, 53, 368, 214);
		frame.getContentPane().add(textPane);
	}
}
