package HomeWork.Task2.CardGame;

public class Players {
    private Card[] Player =new Card[18];

    public void SetPlayer()
    {
        for (int i = 0; i < 18; i++) {
            this.Player[i]=new Card("*","*");
        }
    }

    public void SetCard(Card c,int i)
    {
        Player[i]=c;
    }

    public void Display(){
        for(int i=0;i<18;i++){
            this.Player[i].showCard();
        }
    }

    public static void main(String[] args){
        Players player = new Players();
        player.SetPlayer();
        player.Display();
    }
}
