package HomeWork.Task2.CardGame;

public class Card {
    private String num;
    private String color;
    private boolean mark;
    
    
    public Card(String num,String color)
    {
        this.num=num;
        this.color=color;
        this.mark = true;
    }

    public String GetNum()
    {
        return num;
    }

    public String GetColor()
    {
        return color;
    }
    
    public boolean GetMark()
    {
        return mark;
    }

    public void SetMark(Card c)
    {
        c.mark=false;
    }

    public void showCard()
    {
        System.out.println(this.GetNum()+" "+this.GetColor());
    }
    public static void main(String[] args){
        Card Card1 = new Card("7","♥");
        System.out.println(Card1.GetNum()+" "+Card1.GetColor());
    }
}
