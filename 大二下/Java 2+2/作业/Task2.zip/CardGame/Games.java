package HomeWork.Task2.CardGame;

import java.util.Random;
// import java.util.Arrays;

public class Games {
    public Card[] getCard(){
        int index=0;
        Card[] desk = new Card[52];
        String[] numbers = {"A","2","3","4","5","6","7","8","9","10","J","Q","K"};
        String[] colors={"红桃","黑桃","方片","梅花"};
        for(int i=0;i<4;i++)
            for(int j=0;j<13;j++)
                desk[index++]=new Card(numbers[j],colors[i]);
        return desk;
    }

    public void Display(Card[] desk)
    {
        for(int i=0;i<52;i++)
            desk[i].showCard();
    }

    public Card[] Shuffle(Card[] desk){
        Card[] Processed = new Card[52];
        Random r = new Random();
        int k;
        for(int i=0;i<52;i++)
        {
            do{
                k =r.nextInt(52);
                desk[k].SetMark(desk[k]);
            }while(desk[k].GetMark());
             Processed[i] = desk[k];
        }
        return Processed;   
    } 

    public void GiveCard(Card[] c,Players[] p){
        for(int i=0;i<52;i++)
        {
            if(i%3==0)
                p[0].SetCard(c[i],i/3);
            else if(i%3==1)
                p[1].SetCard(c[i], (i-1)/3);
            else
                p[2].SetCard(c[i],(i-2)/3);
        }
    }

    public static void main(String[] args){
        System.out.println("计科201 夏烨 19220124 完成时间:2002/3/24");
        Games game1=new Games();
        Players[] player=new Players[3];
        for(int i=0;i<3;i++){
            player[i] = new Players();
            player[i].SetPlayer();
        }  
        Card[] origin=game1.getCard();
        System.out.println("Original Card:");
        game1.Display(origin);
        System.out.println();
        System.out.println("After shuffled:");
        Card[] processed=game1.Shuffle(origin);
        game1.Display(processed);
        game1.GiveCard(processed,player);
        for(int i=0;i<3;i++)
        {
            System.out.println("Player"+i);
            player[i].Display();
            System.out.println();
        }
    }
}
