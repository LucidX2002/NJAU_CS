package JMenuDemo;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class DrawListener implements MouseListener,ActionListener {

	public Graphics a;
	int x1,x2,y1,y2;
	public String name;
	
	
	public void setA(Graphics a) {
		Graphics A = a;
	}
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		System.out.println("���");
		//a.drawLine(100,100,400,100);
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		 x1=e.getX();
		 y1=e.getY();
		System.out.println("����");
		

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		 x2=e.getX();
		 y2=e.getY();
	/*if((x1>x2)&&(y1>y2)) {
			a.drawLine(x1, y1, x2, y2);
			//    ���Ͻǵ�����   ��  ��  
			a.drawRect(x2, y2, (x1-x2) ,(y1-y2));
		}else if((x1>x2)&&(y1<y2)){
			a.drawLine(x1, y1, x2, y2);
			//    ���Ͻǵ�����   ��  ��  
			a.drawRect(x2, y1, (x1-x2) ,(y2-y1));
		}else if((x1<x2)&&(y1>y2)){
			a.drawLine(x1, y1, x2, y2);
			//    ���Ͻǵ�����   ��  ��  
			a.drawRect(x1, y2, (x2-x1) ,(y1-y2));
		}else if((x1<x2)&&(y1<y2)){
			a.drawLine(x1, y1, x2, y2);
			//    ���Ͻǵ�����   ��  ��  .
			a.drawRect(x1, y1, (x2-x1) ,(y2-y1));
		
		}*/
	
		 //ѡ��ͬ��ͼ�ν��л��ƣ��԰�ť�ϵ��ı���������
		 
		if("ֱ��".equals(name)) {
		 a.drawLine(x1, y1, x2, y2);
		 }
		if ("����".equals(name)){
		 a.drawRect(Math.min(x1, x2),Math.min(y1, y2),Math.abs(x2-x1),Math.abs(y2-y1));
		 }
		if("��Բ".equals(name)) {
			a.drawOval(Math.min(x1, x2),Math.min(y1, y2),Math.abs(x2-x1),Math.abs(y2-y1));
		}
		
		if("����".equals(name)) {
		
		double x = 0,y = 0;
		double a1=-1.8,b=-2.0,c=-0.5,d=-0.9;
		for(int i=0;i<100000;i++) {
		
		
		double x3=Math.sin(a1*y)-c*Math.cos(a1*x);
		double y3=Math.sin(b*x)-d*Math.cos(b*y);
		x=x3;
		y=y3;
		int px=(int)(x3*100+x1);
		int py=(int)(y3*100+y1);
		
		a.drawLine(px, py, px, py);
		}
		}
		if("����".equals(name)) {
			
		double x4 = 0,y4 = 0;
		double a2=1.40,b2=1.56,c2=1.40,d2=-6.56;
		for(int i=0;i<100000;i++) {
		
		
			double x5=Math.sin(a2*x4)-Math.cos(b2*y4);
			double y5=Math.sin(c2*x4)-Math.cos(d2*y4);
			x4=x5;
			y4=y5;
			int px=(int)(x5*100+x1);
			int py=(int)(y5*100+y1);
		
			a.drawLine(px, py, px, py);
			}
		}
		
		if("������".equals(name)) {
            a.drawLine(x1, y1, x2, y2); //(x1, y1) ,(x2, y2), (x1, y2)
            a.drawLine(x1, y1, x1, y2);
            a.drawLine(x2, y2, x1, y2);
        }
		
		 System.out.println("�ͷ�");
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		System.out.println("����");
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		System.out.println("�뿪");
	}
	
	public void actionPerformed(ActionEvent e) {
		if("".equals(e.getActionCommand())) {
			
			JButton jb= (JButton)e.getSource();
			
			Color color=jb.getBackground();//��ȡ��ť�ı�����ɫ
			a.setColor(color);//����������Ϊ��ť�ı�����ɫ
			
			
		}else {
			name=e.getActionCommand();
		}
	}
}

